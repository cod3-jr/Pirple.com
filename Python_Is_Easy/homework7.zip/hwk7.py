"""
    Date:   2021-03-06
    Dev:    Me
    Purpose: refactor list all of the attributes I think are needed
    for storing details about my favorite song as a dictionary, then 
    loop through the dictionary, printing keys and values
    Extra: guessing game function
        returns true if user input of key and value matches key, value
        in dictionary

"""

favArtist = {
    'AlbumArt': '\\Music Man\\Best Album\\winning'
    ,'Artist':  'Music Man'
    ,'DurationSecs': 420
    ,'Genre': 'kaleidascope'
    ,'Rating': 4.5
    ,'Title': 'winning'
}

# Loop through key, value pairs and print them
for k, v in favArtist.items():
    print(k,': ',v)

# function for guessing key and value
def guessKeyVal (key, value):
    try:
        if value == favArtist[key]:
            return True
        else:
            return False
    except(KeyError):
        return False

# For Testing
# test = guessKeyVal('Artist','Music Man')
# print(test)