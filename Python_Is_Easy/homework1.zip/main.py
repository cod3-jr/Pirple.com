"""
    Date:   2021-02-03
    Dev:    Me
    Purpose: list all of the attributes I think are needed
    for storing details about my favorite song

"""

AlbumArt = "\Music Man\Best Album\winning"
Artist = "Music Man"
DurationSecs = 420 # length of song in seconds
Genre  = "kaleidascope"
Rating = 4.5
Title = "winning"

print(AlbumArt,Artist,DurationSecs,Genre,Rating,Title, sep="\n", end="\n")